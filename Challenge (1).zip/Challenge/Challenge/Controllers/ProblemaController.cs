﻿using Microsoft.AspNetCore.Mvc;
using Challenge.Models;
using Challenge.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Challenge.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProblemaController : ControllerBase
    {
        private readonly IProblemaService _problemaService;

        public ProblemaController(IProblemaService problemaService)
        {
            _problemaService = problemaService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Problema>>> GetProblemas()
        {
            var problemas = await _problemaService.GetAllProblemasAsync();
            return Ok(problemas);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Problema>> GetProblema(int id)
        {
            var problema = await _problemaService.GetProblemaByIdAsync(id);

            if (problema == null)
            {
                return NotFound();
            }

            return problema;
        }

        [HttpPost]
        public async Task<ActionResult<Problema>> CreateProblema(Problema problema)
        {
            await _problemaService.CreateProblemaAsync(problema);
            return CreatedAtAction(nameof(GetProblema), new { id = problema.IdUsuario }, problema);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProblema(String id, Problema problema)
        {
            if (id != problema.IdUsuario)
            {
                return BadRequest();
            }

            await _problemaService.UpdateProblemaAsync(problema);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProblema(int id)
        {
            await _problemaService.DeleteProblemaAsync(id);
            return NoContent();
        }
    }
}
