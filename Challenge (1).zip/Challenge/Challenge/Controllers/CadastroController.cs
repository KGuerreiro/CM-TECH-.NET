﻿using Microsoft.AspNetCore.Mvc;
using Challenge.Models;
using Challenge.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Challenge.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CadastroController : ControllerBase
    {
        private readonly ICadastroService _cadastroService;

        public CadastroController(ICadastroService cadastroService)
        {
            _cadastroService = cadastroService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Cadastro>>> GetCadastros()
        {
            var cadastros = await _cadastroService.GetAllCadastrosAsync();
            return Ok(cadastros);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Cadastro>> GetCadastro(int id)
        {
            var cadastro = await _cadastroService.GetCadastroByIdAsync(id);

            if (cadastro == null)
            {
                return NotFound();
            }

            return cadastro;
        }

        [HttpPost]
        public async Task<ActionResult<Cadastro>> CreateCadastro(Cadastro cadastro)
        {
            await _cadastroService.CreateCadastroAsync(cadastro);
            return CreatedAtAction(nameof(GetCadastro), new { id = cadastro.IdUsuario }, cadastro);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCadastro(String id, Cadastro cadastro)
        {
            if (id != cadastro.IdUsuario)
            {
                return BadRequest();
            }

            await _cadastroService.UpdateCadastroAsync(cadastro);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCadastro(int id)
        {
            await _cadastroService.DeleteCadastroAsync(id);
            return NoContent();
        }
    }
}
