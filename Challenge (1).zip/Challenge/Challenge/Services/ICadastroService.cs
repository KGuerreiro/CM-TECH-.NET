﻿using Challenge.Models;

namespace Challenge.Services
{
    public interface ICadastroService
    {
        Task<IEnumerable<Cadastro>> GetAllCadastrosAsync();
        Task<Cadastro> GetCadastroByIdAsync(int id);
        Task CreateCadastroAsync(Cadastro cadastro);
        Task UpdateCadastroAsync(Cadastro cadastro);
        Task DeleteCadastroAsync(int id);
    }
}
