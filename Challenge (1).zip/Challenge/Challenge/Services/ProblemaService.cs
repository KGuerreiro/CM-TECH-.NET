﻿using Challenge.Models;
using Challenge.Repositories;

namespace Challenge.Services
{
    public class ProblemaService : IProblemaService
    {
        private readonly IProblemaRepository _problemaRepository;

        public ProblemaService(IProblemaRepository problemaRepository)
        {
            _problemaRepository = problemaRepository;
        }

        public async Task<IEnumerable<Problema>> GetAllProblemasAsync()
        {
            return await _problemaRepository.GetAllProblemasAsync();
        }

        public async Task<Problema> GetProblemaByIdAsync(int id)
        {
            return await _problemaRepository.GetProblemaByIdAsync(id);
        }

        public async Task CreateProblemaAsync(Problema problema)
        {
            await _problemaRepository.CreateProblemaAsync(problema);
        }

        public async Task UpdateProblemaAsync(Problema problema)
        {
            await _problemaRepository.UpdateProblemaAsync(problema);
        }

        public async Task DeleteProblemaAsync(int id)
        {
            await _problemaRepository.DeleteProblemaAsync(id);
        }
    }
}
