﻿using Challenge.Models;

namespace Challenge.Services
{
    public interface IProblemaService
    {
        Task<IEnumerable<Problema>> GetAllProblemasAsync();
        Task<Problema> GetProblemaByIdAsync(int id);
        Task CreateProblemaAsync(Problema problema);
        Task UpdateProblemaAsync(Problema problema);
        Task DeleteProblemaAsync(int id);
    }
}
