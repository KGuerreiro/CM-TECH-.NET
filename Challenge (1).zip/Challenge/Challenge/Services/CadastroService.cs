﻿using Challenge.Models;
using Challenge.Repositories;

namespace Challenge.Services
{
    public class CadastroService : ICadastroService
    {
        private readonly ICadastroRepository _cadastroRepository;

        public CadastroService(ICadastroRepository cadastroRepository)
        {
            _cadastroRepository = cadastroRepository;
        }

        public async Task<IEnumerable<Cadastro>> GetAllCadastrosAsync()
        {
            return await _cadastroRepository.GetAllCadastrosAsync();
        }

        public async Task<Cadastro> GetCadastroByIdAsync(int id)
        {
            return await _cadastroRepository.GetCadastroByIdAsync(id);
        }

        public async Task CreateCadastroAsync(Cadastro cadastro)
        {
            await _cadastroRepository.CreateCadastroAsync(cadastro);
        }

        public async Task UpdateCadastroAsync(Cadastro cadastro)
        {
            await _cadastroRepository.UpdateCadastroAsync(cadastro);
        }

        public async Task DeleteCadastroAsync(int id)
        {
            await _cadastroRepository.DeleteCadastroAsync(id);
        }
    }
}
