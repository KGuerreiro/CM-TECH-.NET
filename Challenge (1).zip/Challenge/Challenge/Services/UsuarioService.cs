﻿using Challenge.Data;
using Challenge.Models;
using Challenge.Repositories;
using System.Collections.Generic;
using System.Linq;

namespace Challenge.Services
{
    public class UsuarioService : IUsuarioService
    {
        private readonly IUsuarioRepository _usuarioRepository;

        public UsuarioService(IUsuarioRepository usuarioRepository)
        {
            _usuarioRepository = usuarioRepository;
        }

        public IEnumerable<Usuario> GetAllUsuarios()
        {
            return _usuarioRepository.GetAll();
        }

        public Usuario GetUsuarioById(string id)
        {
            return _usuarioRepository.GetById(id);
        }

        public void AddUsuario(Usuario usuario)
        {
            _usuarioRepository.Add(usuario);
        }

        public void UpdateUsuario(Usuario usuario)
        {
            _usuarioRepository.Update(usuario);
        }

        public void DeleteUsuario(string id)
        {
            _usuarioRepository.Delete(id);
        }
    }

}
