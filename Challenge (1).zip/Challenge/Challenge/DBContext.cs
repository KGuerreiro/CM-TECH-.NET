﻿using Challenge.Models;
using Microsoft.EntityFrameworkCore;

namespace UsuarioService.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Cadastro> Cadastros { get; set; }
        public DbSet<Problema> Problemas { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.ToTable("USUARIO");

                entity.HasKey(e => e.IdUsuario);

                entity.Property(e => e.IdUsuario)
                      .HasColumnName("ID_USUARIO")
                      .HasMaxLength(30);

                entity.Property(e => e.CPF)
                      .HasColumnName("CPF");

                entity.Property(e => e.Nome)
                      .HasColumnName("NOME")
                      .HasMaxLength(50);

                entity.Property(e => e.RG)
                      .HasColumnName("RG");

                entity.Property(e => e.Senha)
                      .HasColumnName("SENHA")
                      .HasMaxLength(50);
            });

            
            modelBuilder.Entity<Cadastro>(entity =>
            {
                entity.ToTable("CADASTRO");

                entity.HasKey(e => e.IdUsuario);

                entity.Property(e => e.IdUsuario)
                      .HasColumnName("ID_USUARIO")
                      .HasMaxLength(30);

                entity.Property(e => e.NomeSite)
                      .HasColumnName("NOME_SITE")
                      .HasMaxLength(100);

                entity.Property(e => e.ServicoSite)
                      .HasColumnName("SERVICO_SITE")
                      .HasMaxLength(1000);

                entity.Property(e => e.EmailSite)
                      .HasColumnName("EMAIL_SITE")
                      .HasMaxLength(50);

                entity.Property(e => e.TelefoneSite)
                      .HasColumnName("TELEFONE_SITE");
            });

            
            modelBuilder.Entity<Problema>(entity =>
            {
                entity.ToTable("PROBLEMAS");

                entity.HasKey(e => e.IdUsuario);

                entity.Property(e => e.IdUsuario)
                      .HasColumnName("ID_USUARIO")
                      .HasMaxLength(30);

                entity.Property(e => e.NomeSite)
                      .HasColumnName("NOME_SITE")
                      .HasMaxLength(100);

                entity.Property(e => e.ProblemaDescricao)
                      .HasColumnName("PROBLEMA")
                      .HasMaxLength(1000);

                entity.Property(e => e.Dificuldade)
                      .HasColumnName("DIFICULDADE")
                      .HasMaxLength(1000);
            });
        }
    }
}