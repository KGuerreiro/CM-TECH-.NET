﻿using Challenge.Data;
using Challenge.Models;
using Microsoft.EntityFrameworkCore;

namespace Challenge.Repositories
{
    public class ProblemaRepository : IProblemaRepository
    {
        private readonly ApplicationDbContext _context;

        public ProblemaRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Problema>> GetAllProblemasAsync()
        {
            return await _context.Problemas.ToListAsync();
        }

        public async Task<Problema> GetProblemaByIdAsync(int id)
        {
            return await _context.Problemas.FindAsync(id);
        }

        public async Task CreateProblemaAsync(Problema problema)
        {
            _context.Problemas.Add(problema);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateProblemaAsync(Problema problema)
        {
            _context.Entry(problema).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteProblemaAsync(int id)
        {
            var problema = await _context.Problemas.FindAsync(id);
            if (problema != null)
            {
                _context.Problemas.Remove(problema);
                await _context.SaveChangesAsync();
            }
        }
    }
}
