﻿using Challenge.Models;

namespace Challenge.Repositories
{
    public interface IUsuarioRepository
    {
        IEnumerable<Usuario> GetAll();
        Usuario GetById(string id);
        void Add(Usuario usuario);
        void Update(Usuario usuario);
        void Delete(string id);
    }

}
