﻿using Challenge.Models;

namespace Challenge.Repositories
{
    public interface IProblemaRepository
    {
        Task<IEnumerable<Problema>> GetAllProblemasAsync();
        Task<Problema> GetProblemaByIdAsync(int id);
        Task CreateProblemaAsync(Problema problema);
        Task UpdateProblemaAsync(Problema problema);
        Task DeleteProblemaAsync(int id);
    }
}
