﻿using Challenge.Data;
using Challenge.Models;
using Microsoft.EntityFrameworkCore;

namespace Challenge.Repositories
{
    public class CadastroRepository : ICadastroRepository
    {
        private readonly ApplicationDbContext _context;

        public CadastroRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Cadastro>> GetAllCadastrosAsync()
        {
            return await _context.Cadastros.ToListAsync();
        }

        public async Task<Cadastro> GetCadastroByIdAsync(int id)
        {
            return await _context.Cadastros.FindAsync(id);
        }

        public async Task CreateCadastroAsync(Cadastro cadastro)
        {
            _context.Cadastros.Add(cadastro);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateCadastroAsync(Cadastro cadastro)
        {
            _context.Entry(cadastro).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }

        public async Task DeleteCadastroAsync(int id)
        {
            var cadastro = await _context.Cadastros.FindAsync(id);
            if (cadastro != null)
            {
                _context.Cadastros.Remove(cadastro);
                await _context.SaveChangesAsync();
            }
        }
    }
}
