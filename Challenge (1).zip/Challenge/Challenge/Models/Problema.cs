﻿namespace Challenge.Models
{
    public class Problema
    {
        public string IdUsuario { get; set; }
        public string NomeSite { get; set; }
        public string ProblemaDescricao { get; set; }
        public string Dificuldade { get; set; }
    }

}
