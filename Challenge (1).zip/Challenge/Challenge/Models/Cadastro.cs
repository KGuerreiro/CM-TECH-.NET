﻿namespace Challenge.Models
{
    public class Cadastro
    {
        public string IdUsuario { get; set; }
        public string NomeSite { get; set; }
        public string ServicoSite { get; set; }
        public string EmailSite { get; set; }
        public string TelefoneSite { get; set; }
    }

}
