﻿namespace Challenge
{
    public class ConfigurationManager
    {
        private static ConfigurationManager _instance;
        private static readonly object _lock = new object();

        // Propriedade para armazenar as configurações (pode ser de qualquer tipo)
        public string ConfigurationSetting { get; set; }

        // Construtor privado para evitar a criação de instâncias externas
        private ConfigurationManager()
        {
            // Definindo uma configuração padrão
            ConfigurationSetting = "Configuração Inicial";
        }

        // Método para obter a instância única
        public static ConfigurationManager Instance
        {
            get
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new ConfigurationManager();
                    }
                    return _instance;
                }
            }
        }
    }
}